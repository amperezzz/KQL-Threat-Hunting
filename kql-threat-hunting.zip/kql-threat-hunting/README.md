# KQL Threat Hunting

Threat-hunting queries for **Microsoft Sentinel** and **Microsoft Defender XDR** advanced hunting, organized by attack area and mapped to MITRE ATT&CK.

Built and maintained by Andrew Perez, Cloud Security Engineer.

## Queries

| Area | Query | What it finds | MITRE ATT&CK |
|---|---|---|---|
| Identity | [password-spray.kql](identity/password-spray.kql) | One IP failing sign-ins across many accounts | T1110.003 |
| Identity | [mfa-fatigue.kql](identity/mfa-fatigue.kql) | Repeated MFA denials against one user | T1621 |
| Identity | [multi-country-signins.kql](identity/multi-country-signins.kql) | Successful sign-ins from several countries in a short window | T1078 |
| Email | [suspicious-inbox-rules.kql](email/suspicious-inbox-rules.kql) | Inbox rules that delete, hide or move mail (common in BEC) | T1564.008 |
| Email | [phish-url-clicks.kql](email/phish-url-clicks.kql) | Users who clicked links in emails flagged as phishing | T1566.002 |
| Endpoint | [encoded-powershell.kql](endpoint/encoded-powershell.kql) | PowerShell launched with encoded commands | T1059.001, T1027 |

## Where to run them

- **Identity queries** use the `SigninLogs` table and the `TimeGenerated` column. Run them in Microsoft Sentinel or a Log Analytics workspace receiving Entra ID sign-in logs.
- **Email and endpoint queries** use Defender XDR tables (`CloudAppEvents`, `UrlClickEvents`, `EmailEvents`, `DeviceProcessEvents`) and the `Timestamp` column. Run them in Defender XDR advanced hunting, or in Sentinel with the Defender XDR connector (swap `Timestamp` for `TimeGenerated`).

## Tuning

Thresholds (failure counts, time windows) are starting points. Adjust them to your environment's baseline before turning any query into a scheduled analytics rule or custom detection.

## Disclaimer

All queries were written from scratch for this repository. They contain no customer data, tenant IDs or organization-specific details.
